<?php $__env->startSection('broadcramb','Transport'); ?>
<?php $__env->startSection('content'); ?>
       <!-- Hero Section Begin -->
       <?php echo $__env->make('client.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <!-- Hero Section End -->
       <section class="transport-section mt-5 text-center">
        
        <?php $__currentLoopData = $facilities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facility): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
              <h1 class="mt-2"> <?php if($facility): ?>
                <?php echo nl2br(e($facility->title)); ?>

                              <?php endif; ?>
            </h1>
       
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <!-- <p class="mt-2"></p> -->
         <div class="transport-wrapper row ">
           <div class="gallery col-md-6 col-sm-12 mt-5 ">
             <div data-featherlight-gallery data-featherlight-filter="a" class="d-flex flex-wrap text-center p-5">
               <?php $__currentLoopData = $facilitiesDataImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FacilitesImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <a href="<?php if($FacilitesImage): ?>
                   <?php echo e($FacilitesImage->image); ?>

               <?php endif; ?>" data-featherlight="image"><img class="img-fluid"
                src="<?php if($FacilitesImage): ?>
                    <?php echo e($FacilitesImage->image); ?>

                <?php endif; ?>" width="150px" height="auto"></a>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
             </div>
           </div>
           <div class="transport-about col-md-6 col-sm-12 mt-5">
             <div class="transport-menu p-5">
               <h1>Transport Details</h1>

               <hr class="w-75 text-center mb-5">
               <div class="menu-item text-left mb-5 col-sm-12 ">
                 <?php $__currentLoopData = $FacilitiesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $FacilitiesData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if($FacilitiesData->id==1): ?>
                            <p> <?php if($FacilitiesData): ?>
                              <?php echo nl2br(e($FacilitiesData->sub_title)); ?>

                                            <?php endif; ?></p>
                            <p>
                              <?php if($FacilitiesData): ?>
                              <?php echo nl2br(e($FacilitiesData->description)); ?>

                                            <?php endif; ?>
                            </p>
                     <?php endif; ?>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 
               </div>
             </div>
           </div>

         </div>

       </section>



 <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/Transport-facility.blade.php ENDPATH**/ ?>
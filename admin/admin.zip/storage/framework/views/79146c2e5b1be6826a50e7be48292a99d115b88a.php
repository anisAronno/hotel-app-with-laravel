<?php $__env->startSection('broadcramb'); ?>
<?php $__currentLoopData = $facilitiesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitiesDat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if($facilitiesDat): ?>
    <?php echo e($facilitiesDat->page_title); ?>

<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
       <!-- Hero Section Begin -->
       <?php echo $__env->make('client.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <!-- Hero Section End -->

       <section class="gym-section mt-5 text-center">
        <h1 class="mt-5 text-break"> <?php $__currentLoopData = $facilitiesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitiesDa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($facilitiesDa): ?>
                <?php echo nl2br(e($facilitiesDa->sub_title)); ?>

            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></h1>
        
        <div class="gym-wrapper row ">
            <div class="gallery col-md-6 col-sm-12 mt-5 ">
                <div data-featherlight-gallery data-featherlight-filter="a" class="d-flex flex-wrap text-center p-5">

                    <?php $__currentLoopData = $facilitiesDataImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $imagesitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                    <a href="<?php echo e($imagesitem->image); ?>" data-featherlight="image"><img class="img-fluid"
                        src="<?php echo e($imagesitem->image); ?>" width="150px" height="auto"></a>
                    
                    
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
            </div>
            <div class="gym-about col-md-6 col-sm-12 mt-5">
                <div class="gym-menu p-5">
                    <h1 class="text-break">
                        <?php $__currentLoopData = $facilitiesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitiesDa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($facilitiesDa): ?>
                                <?php echo nl2br(e($facilitiesDa->title)); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </h1>
                    <hr class="w-75 text-center mb-5">
                    <div class="menu-item text-left mb-5 col-sm-12 ">
                        <p class="text-break">
                            <?php $__currentLoopData = $facilitiesData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facilitiesDa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($facilitiesDa): ?>
                                <?php echo nl2br(e($facilitiesDa->description)); ?>

                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </p>
                    </div>
                </div>
            </div>

        </div>

    </section>

 <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/gym-facility.blade.php ENDPATH**/ ?>
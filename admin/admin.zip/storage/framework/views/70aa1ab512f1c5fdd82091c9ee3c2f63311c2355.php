<?php $__env->startSection('broadcramb','Common Facility'); ?>
<?php $__env->startSection('content'); ?>
       <!-- Hero Section Begin -->
       <?php echo $__env->make('client.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <!-- Hero Section End -->

       <section class="common-section mt-5 text-center">
        <h1 class="mt-5">Come to Hotel Blue Bird</h1>
                    <div class="common-wrapper row ">
                        <div class="gallery col-md-6 col-sm-12 mt-5 ">
                            <div data-featherlight-gallery data-featherlight-filter="a" class="d-flex flex-wrap text-center p-5">
                                <a href="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" width="150px" height="auto"></a>
                                <a href="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" width="150px" height="auto"></a>
                                <a href="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" width="150px" height="auto"></a>
                                <a href="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" width="150px" height="auto"></a>
                                <a href="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blog-3-500x560.jpg" width="150px" height="auto"></a>
                                <a href="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" data-featherlight="image"><img class="img-fluid"
                                        src="<?php echo e(asset('client/images')); ?>/blognew-2-500x560.jpg" width="150px" height="auto"></a>
                            </div>
                        </div>
                        <div class="common-about col-md-6 col-sm-12 mt-5">
                            <div class="common-menu p-5">
                                <h1>Facilities Details</h1>
                                <hr class="w-75 text-center mb-5">
                                <div class="menu-item text-left mb-5 col-sm-12 ">
                                    <ol>
                                        <li>24 Hour security</li>
                                        <li>Disable rooms & Interconnecting rooms                                </li>
                                        <li>Public computer</li>
                                        <li>Swimming pool/ Jacuzzi</li>
                                        <li>Car parking</li>
                                        <li> Semi open & outdoor restaurant</li>
                                        <li>Spa</li>
                                        <li>Poolside bar                                </li>
                                        <!-- <li>Szechuan Soup</li>
                                        <li>Onion Soup</li>
                                        <li>Chicken Clear Soup</li> -->
                                    </ol>
                                </div>
                            </div>
                        </div>

                    </div>

                </section>


 <?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/common-facility.blade.php ENDPATH**/ ?>
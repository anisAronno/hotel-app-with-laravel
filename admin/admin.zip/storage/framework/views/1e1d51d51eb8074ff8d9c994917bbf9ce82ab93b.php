<section class="extra-services-section text-center m-5 ">
    <!-- <img src="<?php echo e(asset('client/images')); ?>/icon-02.svg" alt="" class="icon-logo mt-5" data-aos="fade-up" data-aos-duration="500"
      data-aos-easing="ease-in-out">
    <p class="mt-3" data-aos="fade-up" data-aos-duration="700" data-aos-easing="ease-in-out">SERVICES</p> -->
    <h1 class="mt-3" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">Extra Services</h1>
    <div class="ex-service mt-5 row" data-aos="fade-up" data-aos-duration="1000" data-aos-easing="ease-in-out">
      <?php
           $i=0;
      ?>

      <?php $__currentLoopData = $aboutESPageDatas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aboutESPageData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $i++
        ?>
      <div class="col-md-3 px-5 mt-5"
      style="background-image: url(<?php echo e(asset('client/images')); ?>/shape.png); background-repeat: no-repeat; background-position: center top;">
      <h3 class="mt-3">
         <?php
             echo $i;
         ?>
      </h3>
      <h4 class="mt-3"><?php echo e($aboutESPageData->title); ?></h4>
      <p class="mt-3 text-muted"  style="word-wrap: break-word;">
          <?php if ($aboutESPageData): ?>
          <?php echo nl2br(e($aboutESPageData->description)); ?>

          <?php endif; ?>
         
      
      </p>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
      
  </div>
    </div>
  </section><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/component/extraServicesSection.blade.php ENDPATH**/ ?>
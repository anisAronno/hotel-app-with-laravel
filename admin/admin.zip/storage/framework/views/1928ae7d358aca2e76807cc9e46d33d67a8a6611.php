<?php $__env->startSection('broadcramb','Rersturant'); ?>
<?php $__env->startSection('content'); ?>


        <!-- Hero Section Start -->
        <div class="resturant-hero mt-5 pt-5">
            <div class="resturant-hero-content text-center">
                </iframe>
                <iframe class="mx-auto" width="80%" height="500" src="<?php if($ResturantAbout): ?>
                <?php echo e($ResturantAbout->video); ?>

                <?php endif; ?>" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
        </div>

      
        <!-- Hero Section End -->

        <section class="resturant-about-section mt-5 text-center">
            <h1 class="mt-5"> Terrace View Restaurant</h1>
            <p class="mt-2">Come to Terrace View restaurant, eat and be happy.</p>
            <div class="resturant-wrapper row ">
                <div class="gallery col-md-6 col-sm-12 mt-5 ">
                    <div data-featherlight-gallery data-featherlight-filter="a" class="d-flex flex-wrap text-center">
                        <?php $__currentLoopData = $ResturantImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ResturantImage): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php if($ResturantImage): ?>
                                <?php echo e($ResturantImage->image); ?>

                                <?php endif; ?>" data-featherlight="image"><img class="img-fluid"
                                        src="<?php if($ResturantImage): ?>
                                        <?php echo e($ResturantImage->image); ?>

                                <?php endif; ?>" width="150px" height="auto">
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        
                    </div>
                </div>
                <div class="resturant-about col-md-6 col-sm-12 mt-5">
                    <div class="resturant-content">
                        <div class="resturant-about text-center">
                            <h2 class="text-break">
                                <?php if($ResturantAbout): ?>
                                <?php echo nl2br(e($ResturantAbout->title)); ?>

                                <?php endif; ?>
                                
                            </h2>
                            <p class="p-5 text-break"> <?php if($ResturantAbout): ?>
                                <?php echo nl2br(e($ResturantAbout->description)); ?>

                            <?php endif; ?></p>
                        </div>

                    </div>
                </div>

            </div>
            <div class="resturant-menu p-5">
                <h1 >Menu Card Details</h1>
                <hr class="w-25 text-center mb-5">
                <div class="row">
                    
                    <?php $__currentLoopData = $ResturantMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ResturantMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ResturantMenu->category==1): ?>
                        <div class="menu-item text-left mb-5 col-md-3 col-sm-12">

                            <div class="card mb-3 menu-heading text-break  text-white bg-dark mb-3" style="max-width: 18rem;">
                                        <div class="card-header text-uppercase">
                                        <?php if($ResturantMenu): ?>
                                         <?php echo nl2br(e($ResturantMenu->title)); ?>

                                        <?php endif; ?>
                                        </div>
                                        <div class="card-body">

                                        <p  class="text-break">
                                            <?php if($ResturantMenu): ?>
                                            <?php echo nl2br(e($ResturantMenu->description)); ?>

                                        <?php endif; ?>
                                        </p>
                                    </div>
                            </div>
                        </div>
                    <?php endif; ?>
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                    

                </div>

            </div>
            <div class="row">
                <div class="resturant-set-menu py-5 col-md-5">
                    <h1>Set Menu </h1>
                    <hr class="w-50 text-center mb-5">
                    <div class="row">
                        <?php $__currentLoopData = $ResturantMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ResturantMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($ResturantMenu->category==2): ?>
                        <div class="menu-item mb-5 col-md-6  col-sm-12">
                            <div class="card mb-3 menu-heading text-break  text-white bg-dark" style="max-width: 18rem;">
                                <div class="card-header text-uppercase">
                                <?php if($ResturantMenu): ?>
                                 <?php echo nl2br(e($ResturantMenu->title)); ?>

                                <?php endif; ?>
                                </div>
                                <div class="card-body">

                                <p  class="text-break">
                                    <?php if($ResturantMenu): ?>
                                    <?php echo nl2br(e($ResturantMenu->description)); ?>

                                <?php endif; ?>
                                </p>
                            </div>
                    </div>

                        </div>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     

                    </div>

                </div>
           

            <div class="resturant-party-menu py-5 col-md-7">
                <h1>Party Menu </h1>
                <hr class="w-50 text-center mb-5">
                <div class="row">
                    <?php $__currentLoopData = $ResturantMenus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ResturantMenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($ResturantMenu->category==3): ?>
                    <div class="menu-item text-center mb-5 col-md-4 col-sm-12">
                        <div class="card mb-3 menu-heading text-break  text-white bg-dark" style="max-width: 18rem;">
                            <div class="card-header text-uppercase">
                            <?php if($ResturantMenu): ?>
                             <?php echo nl2br(e($ResturantMenu->title)); ?>

                            <?php endif; ?>
                            </div>
                            <div class="card-body">

                            <p  class="text-break">
                                <?php if($ResturantMenu): ?>
                                <?php echo nl2br(e($ResturantMenu->description)); ?>

                            <?php endif; ?>
                            </p>
                        </div>
                </div>

                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            </div>


        </section>

        
        <?php echo $__env->make('client.component.testimonial', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/resturant.blade.php ENDPATH**/ ?>
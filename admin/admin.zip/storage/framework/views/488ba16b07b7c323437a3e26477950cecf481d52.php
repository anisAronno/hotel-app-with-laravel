<?php $__env->startSection('broadcramb','Contact'); ?>
<?php $__env->startSection('content'); ?>


    <!-- Hero Section Begin -->
    <?php echo $__env->make('client.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Hero Section End -->

    <div class="row contact-form">
        <!--Get in touch Start-->
        <div class="col-md-6">
            <div class="location">
                <div class="contact-detail p-3">
                    <h2>Get in touch</h2>
                    <font face="times new roman"><?php if ($othersData) {echo $othersData->title;}?>
                    </font><br><br>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <p><i class="far fa-envelope"></i> EMAIL <br>
                           <a class="text-decoration-none text-dark" href="mailto:support@foxuries.com"><?php if ($othersData) {echo $othersData->email;}?></a> </p><br>
                        <p> <i class="fas fa-stopwatch"></i> OPEN HOUR <br>
                            <?php if ($othersData): ?>
                            <?php echo nl2br(e($othersData->opening_hour)); ?>

                            <?php endif; ?> 
                            </p><br>

                    </div>
                    <div class="col-md-6">
                        <p><i class="fas fa-map-marker-alt"></i> ADDRESS<br>

                            <?php if ($othersData): ?>
                            <?php echo nl2br(e($othersData->address)); ?>

                            <?php endif; ?>


                           

                        <p class="mt-2"><i class="fas fa-phone-alt"></i> PHONE <br>
                           <a  class="text-decoration-none text-dark" href="tel: +8005678990"><?php if ($othersData) {echo $othersData->phone;}?></a> <br> <a class="text-decoration-none text-dark" href="tel: +8441800 3355"></a>
                           <a  class="text-decoration-none text-dark" href="tel: +8005678990"><?php if ($othersData) {echo $othersData->phone2;}?></a> <br> <a class="text-decoration-none text-dark" href="tel: +8441800 3355"></a>
                        </p> <br>
                    </div>
                </div>
            </div>
        </div>
        <!--Get in touch END-->

        <!-- Hero Section Begin -->
    <?php echo $__env->make('client.template-part.contact', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Hero Section End -->
    </div>

    <!--Main Div Part END-->


    <!--Google map Start-->
    <div class="map text-center">
        <div id="map-container-google-2" class="z-depth-1-half map-container ">
            <?php if ($othersData) {echo $othersData->gmap;}?>

        </div>
    </div>
    <!--Google Maps END-->





    <?php $__env->startSection('script'); ?>

    <?php $__env->stopSection(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/Contact.blade.php ENDPATH**/ ?>
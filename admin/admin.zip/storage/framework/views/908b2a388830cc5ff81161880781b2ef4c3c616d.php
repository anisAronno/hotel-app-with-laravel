<?php $__env->startSection('content'); ?>

    <div id="mainDivMessage" class="container-fluid d-none">
        <div class="row">
            <div class="col-md-12 p-5">
                <table id="messageDataTable" class="table table-striped table-sm table-bordered" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th class="th-sm">NO</th>
                            <th class="th-sm">Arrived Date</th>
                            <th class="th-sm">Deprature Date</th>
                            <th class="th-sm">Mobile</th>
                            <th class="th-sm">Adult</th>
                            <th class="th-sm">Children</th>
                            <th class="th-sm">Delete</th>
                        </tr>
                    </thead>
                    <tbody id="message_table">


                    </tbody>
                </table>

            </div>
        </div>
    </div>
    <div id="loadDivMessage" class="container">
        <div class="row">
            <div class="col-md-12 p-5 text-center">
                <img class="loding-icon m-5" src="<?php echo e(asset('loader.svg')); ?>" alt="">

            </div>
        </div>
    </div>
    <div id="wrongDivMessage" class="container d-none">
        <div class="row">
            <div class="col-md-12 p-5 text-center">
                <h3>Something Went Wrong!</h3>
            </div>
        </div>
    </div>


      <!-- Modal Message Delete -->
      <div class="modal fade" id="deleteModalMessage" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
      aria-hidden="true">
      <div class="modal-dialog" role="document">
          <div class="modal-content">

              <div class="modal-body p-3 text-center">
                  <h5 class="mt-4">Do you want to Delete</h5>
                  <h5 id="messageDeleteId" class="mt-4  "></h5>
              </div>
              <div class="modal-footer">
                  <button type="button" class="btn btn-sm btn-primary" data-dismiss="modal">No</button>
                  <button data-id="" id="confirmDeleteMessage" type="button" class="btn btn-sm btn-danger">Yes</button>
              </div>
          </div>
      </div>
  </div>
  <!-- Modal Message Delete -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript">


        getBookingData();

//message table

 function getBookingData() {


axios.get('/getBookingdata')
    .then(function(response) {

        if (response.status = 200) {

            $('#mainDivMessage').removeClass('d-none');
            $('#loadDivMessage').addClass('d-none');


            $('#messageDataTable').DataTable().destroy();
            $('#message_table').empty();


            var dataJSON = response.data;
            $.each(dataJSON, function(i, item) {
                $('<tr>').html(
                    "<td>" +i+ " </td>" +
                    "<td class='text-center'>" + dataJSON[i].arrival_date + " </td>" +
                    "<td class='text-center'>" + dataJSON[i].departure_date + " </td>" +
                    "<td class='text-center'>" + dataJSON[i].customer_mobile + " </td>" +
                    "<td class='text-center'>" + dataJSON[i].adult_person + " </td>" +
                    "<td class='text-center'>" + dataJSON[i].children_person + " </td>" +
                    "<td class='text-center'><a class='delDataMessage'  data-id=" + dataJSON[i].id + " ><i class='fas fa-trash-alt'></i></a> </td>"

                ).appendTo('#message_table');
            });


             //MEssage table delete icon click

             $(".delDataMessage").click(function() {

                var id = $(this).data('id');
                $('#messageDeleteId').html(id);
                $('#deleteModalMessage').modal('show');

            })




            $('#messageDataTable').DataTable({"order":false});
            $('.dataTables_length').addClass('bs-select');


        } else {
            $('#wrongDivMessage').removeClass('d-none');
            $('#loadDivMessage').addClass('d-none');

        }


    }).catch(function(error) {

        $('#wrongDivMessage').removeClass('d-none');
        $('#loadDivMessage').addClass('d-none');

    });


}



//  Message delete modal yes button

$('#confirmDeleteMessage').click(function() {
var id = $('#messageDeleteId').html();
//var id = $(this).data('id');
DeleteDataMessage(id);

})


//delete Message function

function DeleteDataMessage(id) {
$('#confirmDeleteMessage').html(
    "<div class='spinner-border spinner-border-sm text-primary' role='status'></div>"); //animation

axios.post('/deleteBookingData', {
        id: id
    })
    .then(function(response) {
        $('#confirmDeleteMessage').html("Yes");

        if (response.status == 200) {


            if (response.data == 1) {
                $('#deleteModalMessage').modal('hide');
                toastr.error('Delete Success.');
                getBookingData();
            } else {
                $('#deleteModalMessage').modal('hide');
                toastr.error('Delete Failed');
                getBookingData();
            }

        } else {
            $('#deleteModalMessage').modal('hide');
            toastr.error('Something Went Wrong');
        }

    }).catch(function(error) {

        $('#deleteModalMessage').modal('hide');
        toastr.error('Something Went Wrong');

    });

}



    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.Layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\project\hotel\admin\resources\views/admin/booking.blade.php ENDPATH**/ ?>
<section class="blog-section text-center mt-5">
    <p>OUR BLOG</p>
    <h1>Articles & News</h1>
    <div class="blog-div d-flex flex-wrap">
      <div class="blog-item" style="background-image: url(<?php echo e(asset('client/images')); ?>/Terrace\ View\ Restaurant2.jpg);">
        <div class="content ">
          <h3>Host a Family Party</h3>
          <p><i class="fas fa-calendar-alt"></i>&nbsp; On December 09, 2020</p>
          <p>When you host a party or family reunion, the special celebrations let you strengthen bonds with…When you
            host
          </p>
          <hr>
          <a href="#"><i class="fas fa-arrow-right"></i>&nbsp;&nbsp;READ MORE</a>
        </div>
      </div>
      <div class="blog-item" style="background-image: url(<?php echo e(asset('client/images')); ?>/resturant.jpg);">
        <div class="content ">
          <h3>Host a BBQ Party</h3>
          <p><i class="fas fa-calendar-alt"></i>&nbsp; On March 19, 2020</p>
          <p>When you host a party or family reunion, the special celebrations let you strengthen bonds with…When you
            host
          </p>
          <hr>
          <a href="#"><i class="fas fa-arrow-right"></i>&nbsp;&nbsp;READ MORE</a>
        </div>
      </div>
      <div class="blog-item" style="background-image: url(<?php echo e(asset('client/images')); ?>/Terrace\ View\ Restaurant8.jpg);">
        <div class="content ">
          <h3>Host a Surprise Party</h3>
          <p><i class="fas fa-calendar-alt"></i>&nbsp; On April 25, 2020</p>
          <p>When you host a party or family reunion, the special celebrations let you strengthen bonds with…When you
            host
          </p>
          <hr>
          <a href="#"><i class="fas fa-arrow-right"></i>&nbsp;&nbsp;READ MORE</a>
        </div>
      </div>

    </div>
  </section>
<?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/component/blogSection.blade.php ENDPATH**/ ?>

<?php $__env->startSection('broadcramb','Rooms'); ?>
<?php $__env->startSection('content'); ?>


<!-- Hero Section Begin -->
<?php echo $__env->make('client.component.hero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Hero Section End -->





<section class="room-section-page text-center m-5 row">


    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <div class="room-item-1 col-md-4 col-sm-12 col-lg-4 my-3">
        <div class="text-left room-item-content"
                style="background-image: url('<?php echo e($item->images); ?>'); ">
            <div class=" room-item-content-detail">
                <a href="<?php echo e(route('singleRoom', ['roomId'=>$item->id])); ?>" class="text-decoration-none">
                    <h3><?php echo e($item->title); ?></h3>
                </a>
                <p><span><i class="fas fa-compress"></i>&nbsp; &nbsp; <?php echo e($item->length); ?>m<sup>2</sup></span><span class="ml-2"><a
                    href="#" class="text-decoration-none font-weight-bold"><i
                    class="far fa-folder-open"></i>Balcony</a></span></span>, <span> <a href="#"
                        class="text-decoration-none font-weight-bold">Lake view, Price</a></span></p>
                        
                        <p>
                        <span class="room-item-price">&#2547; <?php echo e($item->price); ?> </span>
                            
                            
                        </p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('client.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/rooms.blade.php ENDPATH**/ ?>
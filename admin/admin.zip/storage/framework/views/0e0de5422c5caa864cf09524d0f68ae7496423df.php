  <!-- Hero Section End -->
        <!-- Hero Section Start -->
        <div class="hero" style="background-image:url('<?php echo e(asset('client/images')); ?>/bg-breadcrumb_about.jpg');">
            <div class="hero-content">
                <h1>Room</h1>
                <p class="ml-3"><span></span><a href="/ ">Home</a></span> <span>/</span> <span><a href="">
                    <?php echo $__env->yieldContent('broadcramb'); ?>
                </a>
                    </span> </p>
            </div>
        </div>
        <!-- Hero Section End --><?php /**PATH C:\Users\Windows 10\Desktop\hotel\admin\resources\views/client/component/hero.blade.php ENDPATH**/ ?>

      <section class="review-section mt-5">
        <div class="text-center">
          <a href="https://www.booking.com/hotel/bd/bluebird-ltd.html">
          <img src="{{asset('client/images')}}/booking .com logodesgin.png" alt="" >
         </a>
          <span class="review-devidor">Foxuries Resort & Hotel Booking</span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star checked"></span>
          <span class="fa fa-star"></span>
          <span class="fa fa-star"></span>
          <span>46 (Reviews)</span>
        </div>
      </section>

 <section class="summer-section row mt-5 m-0 p-0">
        <div class="summer-content col-md-4 col-sm-12 col-lg-4 text-center text-md-left text-sm-center">
          <h4>Be Our Guest and Make Every Stay Memorable</h4>
          <a href="#"><i class="fas fa-arrow-right"></i>&nbsp;LEARN MORE</a>
        </div>
        <div class="summer-image col-md-8 col-sm-12 col-lg-8">
          <img src="{{asset('client/images')}}/h1_shape-people.png" alt="">
        </div>
 </section> 
<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bookingModel extends Model
{
    public $table = 'booking';
    public $timestamps = false;
}
